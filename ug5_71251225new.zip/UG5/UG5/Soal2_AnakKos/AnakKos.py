import streamlit as st
import pandas as pd

# --- Title ---
st.title("Aplikasi Keuangan Anak Kos")


# --- Input Uang Bulanan ---
st.subheader("Uang Bulanan")
uang_bulanan = st.number_input("Masukan Uang Bulanan", min_value=0)


# --- Input Pengeluaran ---
st.subheader("Pengeluaran Bulanan")
makanan = st.number_input("Makanan", min_value=0)
kos = st.number_input("Kos", min_value=0)
transportasi = st.number_input("Transportasi", min_value=0)
internet = st.number_input("Internet/pulsa", min_value=0)
hiburan = st.number_input("Hiburan", min_value=0)

# --- Tombol Ngitung Pengeluaran ---
if st.button("Hitung Pengeluaran"):

    # --- Ngitung Total Pengeluaran ---
    total_pengeluaran = makanan + kos +transportasi + internet + hiburan 

    # --- Ngitung Sisa Uang ---
    sisa_uang = uang_bulanan - total_pengeluaran


    # --- Menampilkan Hasil Perhitungan ---
    st.subheader("Ringkasan Keuangan")
    kolom1, kolom2, kolom3 = st.columns(3)
    with kolom1:
        st.metric(
            # Tampilin uang bulanan di sini
            "Uang Bulanan",
            uang_bulanan 
        )
    with kolom2:
        st.metric(
            # Tampilin total pengeluaran di sini
            "Total pengeluaran",
            total_pengeluaran if "total_pengeluaran" in locals() else 0
        )
    with kolom3:
        st.metric(
            # Tampilin sisa uang di sini
            "Sisa uang",
            sisa_uang if "sisa_uang" in locals() else 0
        )


    # --- Kondisi Keuangan ---
    st.subheader("Kondisi Keuangan")

    # Kondisi 1
    if  sisa_uang > 0:
        st.success("keuangan masih aman. masi ada sisa uang.")
        

    # Kondisi 2
    elif sisa_uang ==0 :
        st.warning ("Uang Bulanan Sudah Habis")

    # Kondisi 3
    else:
        st.error("Pengeluaran Melebihi Uang Bulanan.")
    


    # --- Data Pengeluaran ---
    # Ini gausah diubah! 
    # Udah kubantu bikinin, tinggal dipake aja
    data_pengeluaran = {
        "Kategori": [
            "Makanan",
            "Kos",
            "Transportasi",
            "Internet/Pulsa",
            "Hiburan"
        ],
        "Pengeluaran": [
            makanan,
            kos,
            transportasi,
            internet,
            hiburan
        ]
    }

    df_pengeluaran = pd.DataFrame(data_pengeluaran)

    # --- Pengeluaran Terbesar ---
    Pengeluaran_terbesar = df_pengeluaran.loc [
        df_pengeluaran["Pengeluaran"]. idxmax()
        ] # Cari pengeluaran terbesar

    st.subheader("Pengeluaran Terbesar")
    
    st.write(
            f"kategori: {Pengeluaran_terbesar ['Kategori']}"
            )# Tampilin pengeluaran terbesar di sini


    # --- Grafik Pengeluaran ---
    st.subheader("Grafik Pengeluaran")
    st.bar_chart(
        df_pengeluaran.set_index("Kategori")
        )# Tampilin grafik pengeluaran di sini